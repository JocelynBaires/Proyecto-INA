<!-- <!DOCTYPE html> -->
<!-- <head>
    <meta charset="utf-8"/>
		<title>INA</title>
		<meta name="viewport" content="width=device-width, initial-scale=1"/>
		<link rel="stylesheet" href="css/estilo.css"/>
</head> -->
<header>
    <nav>
        <ul>
            <li><a href="#"><img src="../../imagenes/Logo.png" width="20px" alt="Image" class="img-fluid"></a></li>
            <li><a href="../Alumnos/Index.php"><span class="segundo"><i class="icon icon-house"></i></span>Alumnos</a>
                <ul>
                    <li><a href="../Alumnos/Index.php">Listado Alumnos</a></li>
                    <li><a href="../Alumnos/Alumno_crear.php">Registrar Nuevo Alumno</a></li>
                    <!-- <li><a href="">Item #3</a></li> -->
                </ul>
            </li>
            <li><a href="../Maestros/Index.php"><span class="quinto"><i class="icon icon-tag"></i></span>Docentes</a>
                <ul>
                    <li><a href="../Maestros/Index.php">Listado Docente</a></li>
                    <li><a href="../Maestros/Maestro_crear.php">Registrar Nuevo Docente</a></li>
                    <!-- <li><a href="#">Item #5</a></li> -->
                </ul>
            </li>
            <li><a href="../materias/index.php"><span class="tercero"><i class="icon icon-tag"></i></span>Asignaturas</a>
                <ul>
                    <li><a href="../materias/index.php">Listado de Asignaturas</a></li>
                    <!-- <li><a href="#">Item #2</a></li>
                    <li><a href="#">Item #3</a></li> -->
                </ul>
            </li>
            <li><a href="../materias/index.php"><span class="cuarto"><i class="icon icon-tag"></i></span>Aulas</a>
                <ul>
                    <li><a href="../materias/index.php">Listado de Aulas</a></li>
                    <!-- <li><a href="#">Item #4</a></li>
                    <li><a href="#">Item #5</a></li> -->
                </ul>
            </li>
            
            <li><a href="#"><span class="quinto"><i class="icon icon-tag"></i></span>Secciones</a>
                <ul>
                    <li><a href="../secciones/index.php">Listado secciones</a></li>
                    <!-- <li><a href="#">Item #4</a></li>
                    <li><a href="#">Item #5</a></li> -->
                </ul>
            </li>
            <li><a href="#"><span class="quinto"><i class="icon icon-tag"></i></span>Horarios</a>
                <ul>
                    <li><a href="../horarios/index.php">Ver horarios</a></li>
                    <!-- <li><a href="#">Item #4</a></li>
                    <li><a href="#">Item #5</a></li> -->
                </ul>
            </li>

    </nav>
</header>

</html>